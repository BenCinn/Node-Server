module.exports = {
  content: ["./html/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [
    require('daisyui')
  ],
}
